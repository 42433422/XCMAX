import json
import os
from typing import Any, Dict, List, Optional, Text

from rasa_sdk import Action, Tracker, FormValidationAction
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.types import DomainDict

AUDIT_LOG = "/app/action_audit.jsonl"


def _audit(event: str, **kw):
    rec = {"event": event, **kw}
    with open(AUDIT_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


class ValidateOrderForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_order_form"

    async def extract_quantity(self, dispatcher, tracker, domain):
        import re
        m = re.search(r"\d+(?:\.\d+)?", tracker.latest_message.get("text", "") or "")
        return {"quantity": float(m.group()) if m else None}

    def validate_quantity(self, value, dispatcher, tracker, domain):
        if value is None or value <= 0 or value > 999:
            dispatcher.utter_message(text="数量必须在 1-999 之间，请重新输入")
            return {"quantity": None}
        return {"quantity": value}


class ActionConfigChange(Action):
    def name(self) -> Text:
        return "action_do_config_change"

    def run(self, dispatcher, tracker, context):
        _audit("action_do_config_change", sender=tracker.sender_id)
        dispatcher.utter_message(text="配置已更新")
        return []


class ActionRefund(Action):
    def name(self) -> Text:
        return "action_do_refund"

    def run(self, dispatcher, tracker, context):
        _audit("action_do_refund", sender=tracker.sender_id)
        dispatcher.utter_message(text="退款已执行")
        return []
