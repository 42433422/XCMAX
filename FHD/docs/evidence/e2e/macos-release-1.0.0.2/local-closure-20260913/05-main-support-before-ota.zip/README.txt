XCAGI 诊断包
------------
将此 ZIP 提供给技术支持即可。
- manifest.json：环境与路径摘要（不含密钥）。
- logs/xcagi.log（若存在）：后端近期日志节选。
- logs/electron-backend.log（若存在）：桌面壳、后端进程与崩溃事件。
- logs/updater-events.jsonl（若存在）：桌面更新事件。
崩溃转储仅在 manifest 中列名，不自动打包；需要时从 crash-dumps/ 单独提供。
数据库文件默认不在包内；如需一并分析请单独发送 backups 下的 .db 备份。
