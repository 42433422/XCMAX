"""Pure, bounded shipment-layout draft transformation; no paths, formulas or DB writes.

Every occupied cell needs an explicit source-bound decision. This deliberately
supports only one visible sheet and conservative local formulas. It is not a
classifier, a universal Excel renderer, or permission to save a formal template.
Original formula caches remain in the source index; draft output caches are removed.
"""

from __future__ import annotations

import hashlib
import io
import re
import time
from copy import deepcopy
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from threading import Event
from typing import BinaryIO, Literal
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

from pydantic import Field

from app.application.etl.batch_plan_contract import Contract, PlanLimits, digest
from app.application.etl.batch_plan_reader import CompleteBatchReader
from app.application.etl.errors import EtlError

_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_CELL = re.compile(r"([A-Z]{1,3})([1-9][0-9]{0,6})")
_TOKEN = re.compile(
    r"\s*(\$?[A-Z]{1,3}\$?[1-9][0-9]{0,6}|\d+(?:\.\d+)?(?:[Ee][+-]?\d+)?|[A-Z][A-Z0-9.]*|<=|>=|<>|[()+*/^%,:=<>-])",
    re.I,
)
_FUNCTIONS = {
    "SUM",
    "MIN",
    "MAX",
    "AVERAGE",
    "COUNT",
    "COUNTA",
    "ABS",
    "ROUND",
    "ROUNDUP",
    "ROUNDDOWN",
    "IF",
    "AND",
    "OR",
    "NOT",
}
_SHEET_TAGS = {
    "sheetPr",
    "dimension",
    "sheetViews",
    "sheetFormatPr",
    "cols",
    "sheetData",
    "mergeCells",
    "printOptions",
    "pageMargins",
    "pageSetup",
}
_VALUE_TAGS = {f"{{{_NS}}}{name}" for name in ("f", "v", "is")}


def _names(value):
    return frozenset(value.split())


# Narrow rendering capability, not semantic keyword classification. Unknown metadata
# blocks rather than being carried into an allegedly de-instanced template.
_XML_TAGS = _names("""
    workbook fileVersion workbookPr bookViews workbookView sheets sheet definedNames
    definedName calcPr worksheet sheetPr outlinePr pageSetUpPr tabColor dimension
    sheetViews sheetView pane selection sheetFormatPr cols col sheetData row c f v is si
    sst r rPr t mergeCells mergeCell printOptions pageMargins pageSetup styleSheet fonts
    font name rFont sz b i u strike outline shadow condense extend color family charset
    scheme vertAlign fills fill patternFill fgColor bgColor borders border left right
    top bottom diagonal vertical horizontal cellStyleXfs cellXfs xf alignment protection
    cellStyles cellStyle numFmts
""")
_XML_ATTRS = _names("""
    appName lastEdited lowestEdited rupBuild date1904 filterPrivacy defaultThemeVersion
    xWindow yWindow windowWidth windowHeight activeTab firstSheet name sheetId state
    localSheetId calcId calcMode fullCalcOnLoad forceFullCalc ref showGridLines
    showRowColHeaders showZeros rightToLeft zoomScale zoomScaleNormal workbookViewId
    xSplit ySplit topLeftCell activePane pane activeCell activeCellId sqref baseColWidth
    defaultRowHeight defaultColWidth customHeight zeroHeight outlineLevelRow
    outlineLevelCol min max width customWidth bestFit style hidden collapsed
    outlineLevel r s t ht spans thickTop thickBot dyDescent count uniqueCount
    summaryBelow summaryRight showOutlineSymbols applyStyles autoPageBreaks fitToPage
    fitToWidth fitToHeight horizontalCentered verticalCentered headings gridLines
    gridLinesSet left right top bottom header footer orientation paperSize scale
    firstPageNumber useFirstPageNumber horizontalDpi verticalDpi copies blackAndWhite
    draft pageOrder usePrinterDefaults val rgb indexed auto theme tint patternType
    diagonalUp diagonalDown outline numFmtId fontId fillId borderId xfId pivotButton
    quotePrefix applyNumberFormat applyFont applyFill applyBorder applyAlignment
    applyProtection horizontal vertical textRotation wrapText shrinkToFit indent
    relativeIndent justifyLastLine readingOrder locked builtinId customBuiltin iLevel
""")
_ENUMS = _names("""
    true false visible auto manual autoNoTable portrait landscape downThenOver
    overThenDown none solid gray125 darkGrid lightGrid single double singleAccounting
    doubleAccounting baseline superscript subscript major minor left right center
    justify distributed general top bottom centerContinuous thin medium thick dashed
    dotted hair dashDot dashDotDot mediumDashed mediumDashDot mediumDashDotDot
    slantDashDot bottomRight bottomLeft topRight topLeft frozen split frozenSplit xl
""")
# Canonical fingerprint of the reviewed, bundled openpyxl Office Theme (no external refs).
# This is an exact capability allowlist, NOT permission for arbitrary themed workbooks.
_OFFICE_THEME_SHA = "b9a80667b2390f6bbd91028b817e1bad1aca5fe3cf4c9f4eb9c237bf6253ea5a"
_FONTS = {"Calibri", "Arial", "Arial Unicode MS", "宋体", "微软雅黑", "SimSun", "Microsoft YaHei"}


_META_ROOTS = {
    "docProps/core.xml": "{http://schemas.openxmlformats.org/package/2006/metadata/core-properties}coreProperties",
    "docProps/app.xml": "{http://schemas.openxmlformats.org/officeDocument/2006/extended-properties}Properties",
    "docProps/custom.xml": "{http://schemas.openxmlformats.org/officeDocument/2006/custom-properties}Properties",
}


def _package_guard(roots):
    relation_types = {
        "xl/workbook.xml": _REL + "/officeDocument",
        "xl/styles.xml": _REL + "/styles",
        "xl/sharedStrings.xml": _REL + "/sharedStrings",
        "docProps/core.xml": "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties",
        "docProps/app.xml": _REL + "/extended-properties",
        "docProps/custom.xml": _REL + "/custom-properties",
    }
    for path in roots:
        if path.startswith("xl/worksheets/"):
            relation_types[path] = _REL + "/worksheet"
        elif path.startswith("xl/theme/"):
            relation_types[path] = _REL + "/theme"
    for path in ("_rels/.rels", "xl/_rels/workbook.xml.rels"):
        root = roots.get(path)
        if root is None:
            _fail("UNSUPPORTED", "包关联不完整")
        rel_ns = "{http://schemas.openxmlformats.org/package/2006/relationships}"
        if root.tag != rel_ns + "Relationships" or root.attrib:
            _fail("UNSUPPORTED", "包关联根结构未覆盖")
        seen = set()
        for node in root:
            target = node.get("Target", "")
            target = (
                target[1:]
                if target.startswith("/")
                else (("xl/" if path.startswith("xl/") else "") + target)
            )
            rid = node.get("Id", "")
            if (
                node.tag != rel_ns + "Relationship"
                or len(node)
                or set(node.attrib) != {"Id", "Type", "Target"}
                or not re.fullmatch(r"rId[0-9]+", rid)
                or rid in seen
                or target not in roots
                or node.get("Type") != relation_types.get(target)
                or (path.startswith("xl/") and target in {"xl/workbook.xml", *_META_ROOTS})
                or (not path.startswith("xl/") and target not in {"xl/workbook.xml", *_META_ROOTS})
            ):
                _fail("UNSUPPORTED", "包关联含外部/未知目标或未覆盖元数据")
            seen.add(rid)
    content_ns = "{http://schemas.openxmlformats.org/package/2006/content-types}"
    content_types = roots["[Content_Types].xml"]
    if content_types.tag != content_ns + "Types" or content_types.attrib:
        _fail("UNSUPPORTED", "内容类型声明根结构未覆盖")
    mime_suffixes = {
        "officeDocument": "officedocument.spreadsheetml.sheet.main",
        "styles": "officedocument.spreadsheetml.styles",
        "sharedStrings": "officedocument.spreadsheetml.sharedStrings",
        "worksheet": "officedocument.spreadsheetml.worksheet",
        "theme": "officedocument.theme",
        "core-properties": "package.core-properties",
        "extended-properties": "officedocument.extended-properties",
        "custom-properties": "officedocument.custom-properties",
    }
    for node in content_types:
        if node.tag == content_ns + "Default":
            valid = set(node.attrib) == {"Extension", "ContentType"} and node.get(
                "ContentType"
            ) == {
                "xml": "application/xml",
                "rels": "application/vnd.openxmlformats-package.relationships+xml",
            }.get(node.get("Extension"))
        else:
            target = node.get("PartName", "").removeprefix("/")
            kind = relation_types.get(target, "").rsplit("/", 1)[-1]
            valid = (
                node.tag == content_ns + "Override"
                and target in roots
                and set(node.attrib) == {"PartName", "ContentType"}
                and kind in mime_suffixes
                and node.get("ContentType")
                == "application/vnd.openxmlformats-" + mime_suffixes[kind] + "+xml"
            )
        if not valid or len(node):
            _fail("UNSUPPORTED", "未知内容类型或包元数据不能保留")
    # Disallow free-text payloads in package declarations that would otherwise be retained.
    for path in ("[Content_Types].xml", "_rels/.rels", "xl/_rels/workbook.xml.rels"):
        for node in roots[path].iter():
            if (node.text or "").strip() or (node.tail or "").strip():
                _fail("UNSUPPORTED", "包声明含未分类文本")


def _metadata_guard(parts, roots):
    for path, root in roots.items():
        if path.startswith("docProps/"):
            continue  # all properties, including namespace names, are erased below
        if re.search(rb"<!--|<\?(?!xml\s)", parts[path]):
            _fail("UNSUPPORTED", "XML 注释/扩展尚未覆盖，未生成部分脱实例模板")
        if path.endswith(".rels") or path == "[Content_Types].xml":
            continue  # checked by _package_guard
        if path.startswith("xl/theme/"):
            canonical = ET.canonicalize(
                ET.tostring(root, encoding="unicode"), rewrite_prefixes=True, strip_text=True
            )
            if hashlib.sha256(canonical.encode()).hexdigest() != _OFFICE_THEME_SHA:
                _fail("UNSUPPORTED", "仅已审标准 Office 主题可保留，其他主题须独立复核")
            continue
        for node in root.iter():
            tag = node.tag.removeprefix(f"{{{_NS}}}")
            if not node.tag.startswith(f"{{{_NS}}}") or tag not in _XML_TAGS:
                _fail("UNSUPPORTED", "存在未覆盖的嵌套元数据/自定义格式或隐藏文本")
            if (node.text or "").strip() and tag not in {"t", "v", "f", "definedName"}:
                _fail("UNSUPPORTED", "非单元文本尚未分类")
            if (node.tail or "").strip():
                _fail("UNSUPPORTED", "XML 尾部文本尚未分类")
            for key, value in node.attrib.items():
                if (
                    tag == "t"
                    and key == "{http://www.w3.org/XML/1998/namespace}space"
                    and value in {"preserve", "default"}
                ):
                    continue
                if tag == "sheet" and key == f"{{{_REL}}}id":
                    continue
                if key not in _XML_ATTRS:
                    _fail("UNSUPPORTED", "未知布局属性尚未分类")
                if key == "name":
                    valid = (
                        tag == "sheet"
                        or (tag == "cellStyle" and value == "Normal")
                        or (
                            tag == "definedName"
                            and value in {"_xlnm.Print_Area", "_xlnm.Print_Titles"}
                        )
                    )
                elif key == "val" and tag in {"name", "rFont"}:
                    valid = value in _FONTS
                elif key == "t" and tag == "c":
                    valid = value in {"n", "b", "str", "d", "s", "inlineStr", "e"}
                else:
                    valid = (
                        value in _ENUMS
                        or re.fullmatch(r"[+-]?[0-9]+(?:\.[0-9]+)?", value)
                        or (key == "rgb" and re.fullmatch(r"[0-9A-Fa-f]{6,8}", value))
                        or (
                            key in {"r", "ref", "activeCell", "sqref", "topLeftCell", "spans"}
                            and re.fullmatch(r"[A-Z0-9:$ ]+", value)
                        )
                    )
                if not valid:
                    _fail("UNSUPPORTED", "布局属性含未覆盖文本；需人工复核而非默默留存")


class TemplateCellDecision(Contract):
    coordinate: str = Field(pattern=r"^[A-Z]{1,3}[1-9][0-9]{0,6}$")
    value_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    role: Literal["structure", "instance", "formula"]
    field_key: str = Field(default="", max_length=80, pattern=r"^(?:[a-z][a-z0-9_]{0,79})?$")


class ShipmentCellPlan(Contract):
    kind: Literal["shipment_layout"] = "shipment_layout"
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_sheet_name: str = Field(min_length=1, max_length=31)
    cells: tuple[TemplateCellDecision, ...] = Field(min_length=1, max_length=10_000)


@dataclass(frozen=True)
class TemplateCellArtifact:
    content: bytes = field(repr=False)
    sha256: str
    source_sha256: str
    plan_digest: str
    audit: tuple[dict, ...]
    cleared_metadata_parts: tuple[str, ...]
    sheet_name: str = "送货单"


def _fail(code, message):
    raise EtlError("ETL_TEMPLATE_" + code, message)


def _q(name):
    return f"{{{_NS}}}{name}"


def _coordinate(value):
    match = _CELL.fullmatch(value.replace("$", "").upper())
    if not match or int(match[2]) > 1_048_576:
        _fail("UNSUPPORTED", "单元格引用超出支持范围")
    column = 0
    for char in match[1]:
        column = column * 26 + ord(char) - 64
    if column > 16_384:
        _fail("UNSUPPORTED", "单元格引用超出支持范围")
    return match[0]


def _safe_formula(value):
    """Parse a conservative pure subset, never evaluate; unknown syntax fails closed."""
    if not value or len(value) > 2000:
        _fail("FORMULA_REVIEW_REQUIRED", "公式为空或超限，需人工复核")
    value = value.strip()
    tokens, cursor = [], 0
    while cursor < len(value):
        match = _TOKEN.match(value, cursor)
        if not match:
            _fail("FORMULA_REVIEW_REQUIRED", "公式含外部/命名/字符串引用或未知语法，需人工复核")
        tokens.append(match[1].upper())
        cursor = match.end()
    if any(
        token == ":"
        and (
            index == 0
            or index + 1 == len(tokens)
            or not _CELL.fullmatch(tokens[index - 1].replace("$", ""))
            or not _CELL.fullmatch(tokens[index + 1].replace("$", ""))
        )
        for index, token in enumerate(tokens)
    ):
        _fail("FORMULA_REVIEW_REQUIRED", "仅支持显式同表单元格区域")
    position = 0

    def expression(depth=0):
        nonlocal position
        if depth > 32 or position >= len(tokens):
            raise ValueError()
        token = tokens[position]
        position += 1
        if token in {"+", "-"}:
            expression(depth + 1)
        elif token == "(":
            expression(depth + 1)
            if position >= len(tokens) or tokens[position] != ")":
                raise ValueError()
            position += 1
        elif token in _FUNCTIONS:
            if position >= len(tokens) or tokens[position] != "(":
                raise ValueError()
            position += 1
            count = 1
            expression(depth + 1)
            while position < len(tokens) and tokens[position] == ",":
                count += 1
                position += 1
                expression(depth + 1)
            if position >= len(tokens) or tokens[position] != ")":
                raise ValueError()
            position += 1
            if (
                (token in {"ABS", "NOT"} and count != 1)
                or (token in {"ROUND", "ROUNDUP", "ROUNDDOWN"} and count != 2)
                or (token == "IF" and count != 3)
                or count > 255
            ):
                raise ValueError()
        elif _CELL.fullmatch(token.replace("$", "")):
            _coordinate(token)
        elif not re.fullmatch(r"\d+(?:\.\d+)?(?:E[+-]?\d+)?", token):
            raise ValueError()
        if position < len(tokens) and tokens[position] == "%":
            position += 1
        if position < len(tokens) and tokens[position] in {
            "+",
            "-",
            "*",
            "/",
            "^",
            ":",
            "=",
            "<",
            ">",
            "<=",
            ">=",
            "<>",
        }:
            position += 1
            expression(depth + 1)

    try:
        expression()
        if position != len(tokens):
            raise ValueError()
    except ValueError:
        _fail("FORMULA_REVIEW_REQUIRED", "公式不在已验证纯函数/同表引用子集，需人工复核")


def _read(source: BinaryIO, expected_sha256: str, limits: PlanLimits):
    if isinstance(source, (str, bytes)):
        _fail("SOURCE_REQUIRED", "模板来源必须是受控已固定文件流，不能重新打开路径")
    source.seek(0)
    raw = source.read(limits.max_index_chars * 4 + 1)
    if len(raw) > limits.max_index_chars * 4 or hashlib.sha256(raw).hexdigest() != expected_sha256:
        _fail("SOURCE_CHANGED", "模板源摘要不符或超过资源上限")
    CompleteBatchReader().index(
        io.BytesIO(raw),
        suffix=".xlsx",
        limits=limits,
        deadline=time.monotonic() + limits.timeout_seconds,
        cancelled=Event(),
    )
    with ZipFile(io.BytesIO(raw)) as archive:
        parts = {name: archive.read(name) for name in archive.namelist()}
    roots = {name: ET.fromstring(data) for name, data in parts.items()}
    if any(
        re.search(r"macroEnabled|vbaProject|activeX|oleObject", value, re.I)
        for node in roots["[Content_Types].xml"].iter()
        for value in node.attrib.values()
    ):
        _fail("UNSUPPORTED", "宏或可执行工作簿内容不支持")
    _package_guard(roots)
    _metadata_guard(parts, roots)
    workbook = roots["xl/workbook.xml"]
    if any(
        node.tag.removeprefix(f"{{{_NS}}}")
        not in {"fileVersion", "workbookPr", "bookViews", "sheets", "definedNames", "calcPr"}
        for node in workbook
    ) or any("codeName" in node.attrib for node in workbook.iter()):
        _fail("UNSUPPORTED", "工作簿含未覆盖的元数据或外部/代码关联")
    sheets = workbook.findall(f"{_q('sheets')}/{_q('sheet')}")
    if len(sheets) != 1 or sheets[0].get("state", "visible") != "visible":
        _fail("UNSUPPORTED", "当前模板切片仅支持单一可见工作表；未丢弃其他页")
    relationships = roots.get("xl/_rels/workbook.xml.rels")
    rid = sheets[0].get(f"{{{_REL}}}id")
    targets = [
        n.get("Target", "")
        for n in (() if relationships is None else relationships)
        if n.get("Id") == rid
    ]
    target = targets[0] if len(targets) == 1 else ""
    sheet_path = target.lstrip("/") if target.startswith("/xl/") else "xl/" + target
    if (
        not re.fullmatch(r"xl/worksheets/sheet\d+\.xml", sheet_path)
        or sheet_path not in roots
        or sum(name.startswith("xl/worksheets/") for name in roots) != 1
    ):
        _fail("UNSUPPORTED", "工作表关联不完整或存在未覆盖页")
    sheet = roots[sheet_path]
    if any(node.tag.removeprefix(f"{{{_NS}}}") not in _SHEET_TAGS for node in sheet):
        _fail("UNSUPPORTED", "注释/验证/链接/其他未覆盖工作表内容须人工复核")
    if any(node.get("hidden") in {"1", "true"} for node in sheet.iter()):
        _fail("UNSUPPORTED", "隐藏行列尚需显式独立审阅，整份模板未生成")
    shared = roots.get("xl/sharedStrings.xml")
    shared = list(shared) if shared is not None else []
    cells = {}
    for row in sheet.findall(f"{_q('sheetData')}/{_q('row')}"):
        for cell in row:
            coordinate = cell.get("r", "")
            if (
                cell.tag != _q("c")
                or _coordinate(coordinate) != coordinate
                or coordinate in cells
                or str(int(_CELL.fullmatch(coordinate)[2])) != row.get("r")
            ):
                _fail("UNSUPPORTED", "重复或无效单元格位置")
            if set(cell.attrib) - {"r", "s", "t"} or any(n.tag not in _VALUE_TAGS for n in cell):
                _fail("UNSUPPORTED", "单元格含未知元数据")
            cells[coordinate] = cell
    if len(cells) > limits.max_units:
        _fail("RESOURCE_LIMIT", "模板单元格超过预算；未截断")
    return parts, roots, sheets[0], sheet_path, cells, shared


def _rich_text(item):
    if item.attrib or (
        list(item)
        and not ((len(item) == 1 and item[0].tag == _q("t")) or all(n.tag == _q("r") for n in item))
    ):
        _fail("UNSUPPORTED", "富文本含未覆盖的隐藏内容")
    for node in item:
        if node.tag == _q("r") and (
            node.attrib or [n.tag for n in node] not in [[_q("t")], [_q("rPr"), _q("t")]]
        ):
            _fail("UNSUPPORTED", "富文本片段结构未覆盖")
    if any(len(n) for n in item.iter(_q("t"))):
        _fail("UNSUPPORTED", "文本节点含未分类子结构")
    return "".join(n.text or "" for n in item.iter(_q("t")))


def _text_markup(cell, shared):
    if cell.get("t") == "s":
        item = deepcopy(shared[int(cell.find(_q("v")).text)])
    elif cell.get("t") == "inlineStr":
        item = deepcopy(cell.find(_q("is")))
    else:
        return None
    item.tag = _q("is")  # shared -> inline is the sole permitted markup conversion
    return ET.canonicalize(ET.tostring(item, encoding="unicode"), rewrite_prefixes=True)


def _value(cell, shared):
    formula, value, inline = cell.find(_q("f")), cell.find(_q("v")), cell.find(_q("is"))
    kind = cell.get("t", "n")
    if any(len(cell.findall(_q(name))) > 1 for name in ("f", "v", "is")) or (
        formula is not None and inline is not None
    ):
        _fail("UNSUPPORTED", "单元格值表示存在歧义")
    if (
        (value is not None and (value.attrib or len(value)))
        or ((inline is not None) != (kind == "inlineStr"))
        or (inline is not None and value is not None)
    ):
        _fail("UNSUPPORTED", "单元格值节点含未覆盖结构")
    if formula is not None:
        if formula.attrib or len(formula):
            _fail("FORMULA_REVIEW_REQUIRED", "数组/共享公式尚未覆盖")
        _safe_formula(formula.text or "")
        return "formula", formula.text or "", digest({"formula": formula.text})
    if kind == "s":
        try:
            item = shared[int(value.text)]
            if int(value.text) < 0:
                raise ValueError()
        except (IndexError, ValueError, AttributeError, TypeError):
            _fail("UNSUPPORTED", "共享字符串引用无效")
        return (
            "text",
            _rich_text(item),
            digest({"shared": ET.tostring(item, encoding="unicode")}),
        )
    if kind == "inlineStr":
        if inline is None:
            _fail("UNSUPPORTED", "内联文本不完整")
        return (
            "text",
            _rich_text(inline),
            digest({"inline": ET.tostring(inline, encoding="unicode")}),
        )
    text = value.text if value is not None else None
    if kind not in {"n", "b", "str", "d"}:
        _fail("UNSUPPORTED", "错误值或未知单元格类型尚未覆盖")
    if text is not None and kind == "n":
        try:
            if not Decimal(text).is_finite():
                raise ValueError()
        except (InvalidOperation, ValueError):
            _fail("UNSUPPORTED", "非有限数值不支持")
    return ("text" if kind in {"str", "d"} else kind), text, digest({"type": kind, "value": text})


def inspect_shipment_cells(
    source: BinaryIO, *, source_sha256: str, limits: PlanLimits | None = None
):
    """Return hashes/locators for the caller's explicit semantic review, not guesses."""
    _, _, sheet, path, cells, shared = _read(source, source_sha256, limits or PlanLimits())
    return {
        "source_sha256": source_sha256,
        "source_sheet_name": sheet.get("name"),
        "cells": [
            {
                "coordinate": key,
                "kind": _value(cell, shared)[0],
                "value_sha256": _value(cell, shared)[2],
                "locator": f"xlsx:part:{path}:cell:{key}",
            }
            for key, cell in cells.items()
        ],
    }


def _layout(root):
    copy = deepcopy(root)
    for cell in copy.iter(_q("c")):
        cell.attrib.pop("t", None)
        for node in list(cell):
            if node.tag in _VALUE_TAGS:
                cell.remove(node)
    return ET.tostring(copy)


def build_shipment_cell_artifact(
    source: BinaryIO,
    plan: ShipmentCellPlan,
    *,
    limits: PlanLimits | None = None,
    allowed_fields: frozenset[str] = frozenset(),
) -> TemplateCellArtifact:
    limits = limits or PlanLimits()
    parts, roots, sheet_ref, path, cells, shared = _read(source, plan.source_sha256, limits)
    if sheet_ref.get("name") != plan.source_sheet_name:
        _fail("SOURCE_CHANGED", "模板页名与计划不一致")
    decisions = {item.coordinate: item for item in plan.cells}
    if len(decisions) != len(plan.cells) or set(decisions) != set(cells):
        _fail("COVERAGE_GAP", "每个实际单元格必须恰好有一项分类，未默默丢弃单元格")
    audit, removed_text = [], []
    for key, cell in cells.items():
        decision = decisions[key]
        kind, value, sha = _value(cell, shared)
        if (
            decision.role not in {"structure", "instance", "formula"}
            or decision.value_sha256 != sha
            or (kind == "formula") != (decision.role == "formula")
            or (decision.role == "instance") != bool(decision.field_key)
            or (decision.field_key and decision.field_key not in allowed_fields)
        ):
            _fail("PLAN_INVALID", "单元格分类、字段位置或来源摘要不一致")
        audit.append(
            {
                "coordinate": key,
                "role": decision.role,
                "field_key": decision.field_key,
                "value_sha256": sha,
                "locator": f"xlsx:part:{path}:cell:{key}",
                "formula_cache_removed": kind == "formula",
            }
        )
        if decision.role == "instance":
            if kind == "text" and value:
                removed_text.append(value)
            cell.attrib.pop("t", None)
            for node in list(cell):
                cell.remove(node)
        elif decision.role == "formula":
            for node in list(cell):
                if node.tag != _q("f"):
                    cell.remove(node)
        elif cell.get("t") == "s":
            item = deepcopy(shared[int(cell.find(_q("v")).text)])
            item.tag = _q("is")
            for node in list(cell):
                cell.remove(node)
            cell.set("t", "inlineStr")
            cell.append(item)
    sheet_ref.set("name", "送货单")
    for node in roots["xl/workbook.xml"].findall(f"{_q('definedNames')}/{_q('definedName')}"):
        if node.get("name") not in {"_xlnm.Print_Area", "_xlnm.Print_Titles"}:
            _fail("UNSUPPORTED", "命名公式/变量尚未覆盖")
        old = "'" + plan.source_sheet_name.replace("'", "''") + "'!"
        text = (
            (node.text or "")
            .replace(old, "'送货单'!")
            .replace(plan.source_sheet_name + "!", "'送货单'!")
        )
        if not re.fullmatch(
            r"'送货单'!\$(?:[A-Z]{1,3}(?:\$[1-9][0-9]*)?|[1-9][0-9]*):\$(?:[A-Z]{1,3}(?:\$[1-9][0-9]*)?|[1-9][0-9]*)(?:,\s*'送货单'!\$(?:[A-Z]{1,3}(?:\$[1-9][0-9]*)?|[1-9][0-9]*):\$(?:[A-Z]{1,3}(?:\$[1-9][0-9]*)?|[1-9][0-9]*))*",
            text,
        ):
            _fail("UNSUPPORTED", "打印范围含未知引用")
        node.text = text
    metadata = tuple(name for name in roots if name.startswith("docProps/"))
    for name in metadata:
        roots[name] = ET.Element(_META_ROOTS[name])
    if "xl/sharedStrings.xml" in roots:
        roots["xl/sharedStrings.xml"] = ET.Element(_q("sst"), count="0", uniqueCount="0")
    for root in roots.values():
        for node in root.iter():
            if any(
                value in text
                for value in removed_text
                for text in [node.text or "", *node.attrib.values()]
            ):
                _fail("INSTANCE_REMAINS", "已标记实例文本在其他位置仍有残留，需重新分类或人工复核")
    changed = {*metadata, path, "xl/workbook.xml", "xl/sharedStrings.xml"}
    output = io.BytesIO()
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        for name in parts:
            # Re-serialize every part: unused namespace declarations are not data channels.
            archive.writestr(name, ET.tostring(roots[name], encoding="utf-8", xml_declaration=True))
    content = output.getvalue()
    # Independent parse of emitted bytes verifies the exact intended value/layout contract.
    original = _read(source, plan.source_sha256, limits)
    reopened = _read(io.BytesIO(content), hashlib.sha256(content).hexdigest(), limits)
    if any(
        ET.tostring(original[1][name]) != ET.tostring(reopened[1][name])
        for name in parts
        if name not in changed
    ) or _layout(original[1][path]) != _layout(reopened[1][path]):
        _fail("READBACK_MISMATCH", "模板结构读回与来源不一致")
    for key, decision in decisions.items():
        cell = reopened[4][key]
        if decision.role == "instance":
            valid = not list(cell)
        elif decision.role == "formula":
            valid = (
                cell.find(_q("v")) is None
                and _value(cell, reopened[5])[:2] == _value(original[4][key], original[5])[:2]
            )
        else:
            valid = _value(cell, reopened[5])[:2] == _value(original[4][key], original[5])[
                :2
            ] and _text_markup(cell, reopened[5]) == _text_markup(original[4][key], original[5])
        if not valid:
            _fail("READBACK_MISMATCH", "模板值/公式独立读回不一致")
    return TemplateCellArtifact(
        content,
        hashlib.sha256(content).hexdigest(),
        plan.source_sha256,
        digest(plan),
        tuple(audit),
        metadata,
    )
