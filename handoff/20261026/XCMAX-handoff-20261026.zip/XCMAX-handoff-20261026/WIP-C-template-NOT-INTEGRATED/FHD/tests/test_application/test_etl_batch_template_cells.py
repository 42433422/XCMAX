"""Synthetic OOXML only; no customer files, output registration or formula evaluation."""

from __future__ import annotations

import hashlib
import io
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

import pytest
from openpyxl import load_workbook

from app.application.etl.batch_template_cells import (
    ShipmentCellPlan,
    TemplateCellDecision,
    build_shipment_cell_artifact,
    inspect_shipment_cells,
)
from app.application.etl.errors import EtlError

N = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL = "http://schemas.openxmlformats.org/package/2006/relationships"
FIELDS = {
    "B1": "customer_name",
    "B2": "document_date",
    "A4": "product_name",
    "B4": "quantity",
    "C4": "unit_price",
}


def fixture_parts():
    strings = [
        "发货单",
        "TESTONLY_CUST_42",
        "Date",
        "2026-10-01",
        "Product",
        "Quantity",
        "TESTONLY_ITEM_9",
        "TESTONLY_UNUSED_INSTANCE",
    ]
    return {
        "[Content_Types].xml": '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>',
        "_rels/.rels": f'<Relationships xmlns="{REL}"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
        "xl/workbook.xml": f'<workbook xmlns="{N}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Source" sheetId="1" r:id="rId1"/></sheets><definedNames><definedName name="_xlnm.Print_Area" localSheetId="0">\'Source\'!$A$1:$D$7</definedName></definedNames><calcPr calcId="1"/></workbook>',
        "xl/_rels/workbook.xml.rels": f'<Relationships xmlns="{REL}"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="/xl/worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>',
        "xl/sharedStrings.xml": f'<sst xmlns="{N}" count="8" uniqueCount="8">'
        + "".join(f"<si><t>{v}</t></si>" for v in strings)
        + "</sst>",
        "xl/styles.xml": f'<styleSheet xmlns="{N}"><fonts count="2"><font><name val="Calibri"/><sz val="11"/></font><font><b/><name val="Calibri"/><sz val="11"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>',
        "docProps/core.xml": '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:creator>TESTONLY_CUST_42</dc:creator></cp:coreProperties>',
        "xl/worksheets/sheet1.xml": f'''<worksheet xmlns="{N}"><dimension ref="A1:D7"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols><col min="1" max="1" width="24" customWidth="1"/></cols><sheetData><row r="1"><c r="A1" t="s" s="1"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row><row r="2"><c r="A2" t="s"><v>2</v></c><c r="B2" t="s"><v>3</v></c></row><row r="3"><c r="A3" t="s"><v>4</v></c><c r="B3" t="s"><v>5</v></c><c r="C3" t="inlineStr"><is><t>Price</t></is></c><c r="D3" t="str"><v>Amount</v></c></row><row r="4" ht="22" customHeight="1"><c r="A4" t="s"><v>6</v></c><c r="B4"><v>3</v></c><c r="C4"><v>7.5</v></c><c r="D4"><f>ROUND(B4*C4,2)</f><v>999</v></c></row><row r="5"><c r="A5" t="inlineStr"><is><t>Total</t></is></c><c r="D5"><f>SUM(D4:D4)</f><v>999</v></c></row><row r="7"><c r="A7" t="inlineStr"><is><t>Approved structure</t></is></c></row></sheetData><mergeCells count="1"><mergeCell ref="A7:B7"/></mergeCells><pageMargins left="0.2" right="0.2" top="0.5" bottom="0.5" header="0.3" footer="0.3"/><pageSetup orientation="landscape" paperSize="9"/></worksheet>''',
    }


def package(parts):
    data = io.BytesIO()
    with ZipFile(data, "w", ZIP_DEFLATED) as archive:
        for name, text in parts.items():
            archive.writestr(name, text)
    return data.getvalue()


def plan_for(raw, *, fields=None):
    fields = FIELDS if fields is None else fields
    inventory = inspect_shipment_cells(
        io.BytesIO(raw), source_sha256=hashlib.sha256(raw).hexdigest()
    )
    return ShipmentCellPlan(
        source_sha256=inventory["source_sha256"],
        source_sheet_name=inventory["source_sheet_name"],
        cells=tuple(
            TemplateCellDecision(
                coordinate=c["coordinate"],
                value_sha256=c["value_sha256"],
                role="instance"
                if c["coordinate"] in fields
                else ("formula" if c["kind"] == "formula" else "structure"),
                field_key=fields.get(c["coordinate"], ""),
            )
            for c in inventory["cells"]
        ),
    )


def build(raw, plan=None):
    return build_shipment_cell_artifact(
        io.BytesIO(raw), plan or plan_for(raw), allowed_fields=frozenset(FIELDS.values())
    )


def test_explicit_all_cell_plan_clears_instances_metadata_and_cache_preserves_layout_formula():
    parts = fixture_parts()
    raw = package(parts)
    artifact = build(raw)
    assert artifact.source_sha256 == hashlib.sha256(raw).hexdigest()
    assert artifact.sha256 == hashlib.sha256(artifact.content).hexdigest()
    assert artifact.cleared_metadata_parts == ("docProps/core.xml",)
    assert sum(row["role"] == "instance" for row in artifact.audit) == 5
    assert sum(row["formula_cache_removed"] for row in artifact.audit) == 2
    with ZipFile(io.BytesIO(artifact.content)) as output:
        texts = [output.read(name).decode() for name in output.namelist()]
        assert not any(
            "TESTONLY_" in text or "2026-10-01" in text or "<v>999</v>" in text for text in texts
        )
        assert ET.tostring(ET.fromstring(output.read("xl/styles.xml"))) == ET.tostring(
            ET.fromstring(parts["xl/styles.xml"])
        )
        assert not list(ET.fromstring(output.read("xl/sharedStrings.xml")))
    # Independent Office reader, not the transformer, verifies actual reopen semantics.
    workbook = load_workbook(io.BytesIO(artifact.content), data_only=False)
    sheet = workbook["送货单"]
    assert all(sheet[address].value is None for address in FIELDS)
    assert sheet["A1"].value == "发货单" and sheet["A1"].font.bold
    assert sheet["D4"].value == "=ROUND(B4*C4,2)" and sheet["D5"].value == "=SUM(D4:D4)"
    assert sheet.column_dimensions["A"].width == 24 and sheet.row_dimensions[4].height == 22
    assert (
        str(next(iter(sheet.merged_cells.ranges))) == "A7:B7"
        and sheet.page_setup.orientation == "landscape"
    )
    assert "$A$1:$D$7" in str(sheet.print_area)
    workbook.close()
    cache_reader = load_workbook(io.BytesIO(artifact.content), data_only=True)
    assert cache_reader.active["D4"].value is None  # NOT recomputed to 22.5
    cache_reader.close()
    assert b"<v>999</v>" in ZipFile(io.BytesIO(raw)).read("xl/worksheets/sheet1.xml")


@pytest.mark.parametrize("change", ["missing", "duplicate", "digest", "role", "field", "source"])
def test_plan_coverage_source_and_host_field_catalog_are_strict(change):
    raw = package(fixture_parts())
    plan = plan_for(raw)
    if change == "missing":
        plan = plan.model_copy(update={"cells": plan.cells[:-1]})
    elif change == "duplicate":
        plan = plan.model_copy(update={"cells": (*plan.cells, plan.cells[0])})
    elif change == "source":
        plan = plan.model_copy(update={"source_sha256": "0" * 64})
    else:
        patch = {
            "digest": {"value_sha256": "0" * 64},
            "role": {"role": "formula"},
            "field": {"field_key": "invented_schema_field", "role": "instance"},
        }[change]
        plan = plan.model_copy(
            update={"cells": (plan.cells[0].model_copy(update=patch), *plan.cells[1:])}
        )
    with pytest.raises(EtlError):
        build(raw, plan)


@pytest.mark.parametrize(
    "formula",
    [
        "cmd|' /C calc'!A0",
        "[1]Sheet1!A1",
        "'Source'!A1",
        'HYPERLINK("https://invalid")',
        'WEBSERVICE("https://invalid")',
        'IMAGE("https://invalid")',
        'INDIRECT("A1")',
        'RTD("server",,A1)',
        'EXEC("cmd")',
        "_xlfn.UNKNOWN(A1)",
        "SUM(UnknownName)",
        "ROUND(A1)",
        "SUM(1:2)",
        "SUM(A1",
        "A1+",
    ],
)
def test_unsafe_or_uncovered_formula_blocks_without_execution(formula):
    parts = fixture_parts()
    parts["xl/worksheets/sheet1.xml"] = parts["xl/worksheets/sheet1.xml"].replace(
        "ROUND(B4*C4,2)", formula.replace("&", "&amp;")
    )
    with pytest.raises(EtlError) as error:
        build(package(parts))
    assert error.value.code in {"ETL_TEMPLATE_FORMULA_REVIEW_REQUIRED", "ETL_BATCH_INDEX_INVALID"}


@pytest.mark.parametrize(
    "channel",
    [
        "hidden_row",
        "hidden_column",
        "hidden_sheet",
        "second_sheet",
        "macro",
        "comment",
        "external",
        "validation",
        "named_formula",
    ],
)
def test_hidden_and_unsupported_channels_block_whole_artifact(channel):
    parts = fixture_parts()
    if channel == "hidden_row":
        parts["xl/worksheets/sheet1.xml"] = parts["xl/worksheets/sheet1.xml"].replace(
            '<row r="4"', '<row r="4" hidden="1"'
        )
    elif channel == "hidden_column":
        parts["xl/worksheets/sheet1.xml"] = parts["xl/worksheets/sheet1.xml"].replace(
            '<col min="1"', '<col hidden="1" min="1"'
        )
    elif channel == "hidden_sheet":
        parts["xl/workbook.xml"] = parts["xl/workbook.xml"].replace(
            "<sheet name=", '<sheet state="hidden" name='
        )
    elif channel == "second_sheet":
        parts["xl/worksheets/sheet2.xml"] = parts["xl/worksheets/sheet1.xml"]
    elif channel == "macro":
        parts["xl/vbaProject.bin"] = "TESTONLY never executed"
    elif channel == "comment":
        parts["xl/comments/comment1.xml"] = "<comment>TESTONLY comment</comment>"
    elif channel == "external":
        parts["xl/_rels/workbook.xml.rels"] = parts["xl/_rels/workbook.xml.rels"].replace(
            'Target="styles.xml"', 'TargetMode="External" Target="https://invalid"'
        )
    elif channel == "validation":
        parts["xl/worksheets/sheet1.xml"] = parts["xl/worksheets/sheet1.xml"].replace(
            "</worksheet>",
            "<dataValidations><dataValidation><formula1>TESTONLY</formula1></dataValidation></dataValidations></worksheet>",
        )
    else:
        parts["xl/workbook.xml"] = parts["xl/workbook.xml"].replace(
            "_xlnm.Print_Area", "custom_data_name"
        )
    with pytest.raises(EtlError):
        build(package(parts))


def test_instance_marked_in_one_cell_cannot_remain_in_structure_elsewhere():
    parts = fixture_parts()
    parts["xl/worksheets/sheet1.xml"] = parts["xl/worksheets/sheet1.xml"].replace(
        "Approved structure", "Customer TESTONLY_CUST_42"
    )
    with pytest.raises(EtlError) as error:
        build(package(parts))
    assert error.value.code == "ETL_TEMPLATE_INSTANCE_REMAINS"


def test_stream_only_and_output_contains_no_source_values_in_repr():
    raw = package(fixture_parts())
    plan = plan_for(raw)
    with pytest.raises(EtlError, match="文件流"):
        build_shipment_cell_artifact("not-a-customer-path", plan)
    assert "TESTONLY" not in repr(build(raw))
