"""Absorbed planner chat adapter with request-scoped tool execution."""

from __future__ import annotations

import copy
import json
import os
import threading
from collections.abc import Sequence
from concurrent.futures import ThreadPoolExecutor
from contextvars import Context, ContextVar, copy_context
from typing import Any, cast

from app.application.workflow.multimodal_user_content import (
    EmptyMultimodalResponseError as EmptyMultimodalResponseError,
)
from app.application.workflow.multimodal_user_content import (
    build_openai_user_content as build_openai_user_content,
)
from app.application.workflow.multimodal_user_content import (
    messages_have_image_parts as messages_have_image_parts,
)
from app.domain.context.session_context import (
    enrich_excel_tool_arguments,
)
from app.domain.context.session_context import (
    merge_system_prompt as merge_system_prompt,
)
from app.infrastructure.llm.client import (
    get_openai_compatible_client as get_openai_compatible_client,
)
from app.infrastructure.llm.client import (
    require_api_key as require_api_key,
)
from app.infrastructure.llm.client import (
    resolve_chat_model,
)

_PLANNER_TOOL_STREAM_LABELS: dict[str, str] = {
    "generate_office_document": "生成可下载文档（Word 或 Excel）",
    "import_excel_to_database": "导入 Excel 到数据库",
    "excel_analysis": "读取或分析 Excel",
    "excel_schema_understand": "识别 Excel 表结构",
    "excel_join_compare": "合并或对比 Excel 文件",
    "excel_chart_recommend": "根据数据推荐图表",
    "products_bulk_import": "批量导入产品数据",
}


def _get_workflow_tool_registry():
    from app.mod_sdk.planner_tools import (
        get_planner_chat_tool_registry,
        is_planner_tools_via_mod_enabled,
    )

    if is_planner_tools_via_mod_enabled():
        return get_planner_chat_tool_registry()
    from app.application.tools.workflow import get_workflow_tool_registry as _impl

    return _impl()


def _resolve_chat_execute_tool():
    from app.mod_sdk.planner_tools import resolve_planner_tool_executor

    return resolve_planner_tool_executor()


_TOOL_DEDUP: ContextVar[set[str] | None] = ContextVar("_TOOL_DEDUP", default=None)
_TOOL_DEDUP_LOCK = threading.Lock()
_LAST_TOOL_TRACE = threading.local()
_LAST_TOOL_RESULT: ContextVar[dict[str, Any] | None] = ContextVar("_LAST_TOOL_RESULT", default=None)

# 这些工具可能在首轮就返回 requires_token,后续工具在串行语义下不应被执行;并行会改变该顺序。
_TOKEN_ORDER_SENSITIVE_TOOLS = frozenset({"import_excel_to_database", "products_bulk_import"})


def _resolve_chat_model_for_client(client: Any | None, explicit_model: str | None) -> str:
    if explicit_model:
        return explicit_model
    if client is not None and getattr(client, "is_modstore_openai_compatible", False):
        default_model = str(getattr(client, "default_model", "") or "").strip()
        default_provider = str(getattr(client, "default_provider", "") or "").strip()
        if default_model:
            return f"{default_provider}/{default_model}" if default_provider else default_model
    return cast(str, resolve_chat_model())


def reset_planner_tool_dedup_state() -> None:
    """Start an isolated tool-call deduplication scope for one chat request."""
    _TOOL_DEDUP.set(set())
    clear_last_tool_result()


def _tool_dedup_state() -> set[str]:
    """Return the current request's deduplication state without sharing it globally."""
    state = _TOOL_DEDUP.get()
    if state is None:
        state = set()
        _TOOL_DEDUP.set(state)
    return state


def clear_last_tool_result() -> None:
    _LAST_TOOL_TRACE.records = []


def get_last_tool_records() -> list[dict[str, Any]]:
    records = getattr(_LAST_TOOL_TRACE, "records", [])
    if not isinstance(records, list):
        return []
    return copy.deepcopy([item for item in records if isinstance(item, dict)])


def get_last_tool_result() -> dict[str, Any]:
    records = get_last_tool_records()
    if not records:
        return {}
    last = records[-1]
    output = last.get("output")
    result = copy.deepcopy(output) if isinstance(output, dict) else {"message": str(output or "")}
    result.setdefault("tool_key", last.get("tool_id") or last.get("tool_name") or "")
    result.setdefault("tool_name", last.get("tool_name") or last.get("tool_id") or "")
    result.setdefault("tool_call_id", last.get("tool_call_id") or "")
    result.setdefault("tool_params", copy.deepcopy(last.get("params") or {}))
    result["_tool_records"] = records
    return result


def _attach_last_tool_records(payload: dict[str, Any]) -> dict[str, Any]:
    records = get_last_tool_records()
    if records:
        payload["legacy_tool_records"] = records
    return payload


def _tool_action_from_payload(tool_name: str, params: dict[str, Any]) -> str:
    action = str(params.get("action") or "").strip()
    if action:
        return action
    if tool_name in {"excel_analysis", "excel_schema_understand"}:
        return "read"
    return "execute"


def _append_last_tool_record(
    tc: Any,
    tool_name: str,
    raw_arguments: str,
    payload: dict[str, Any],
) -> None:
    try:
        params = json.loads(raw_arguments) if str(raw_arguments or "").strip() else {}
        if not isinstance(params, dict):
            params = {}
    except json.JSONDecodeError:
        params = {}
    records = getattr(_LAST_TOOL_TRACE, "records", [])
    if not isinstance(records, list):
        records = []
    output = (
        copy.deepcopy(payload) if isinstance(payload, dict) else {"message": str(payload or "")}
    )
    records.append(
        {
            "tool_id": str(tool_name or "").strip(),
            "tool_name": str(tool_name or "").strip(),
            "action": _tool_action_from_payload(str(tool_name or "").strip(), params),
            "params": copy.deepcopy(params),
            "output": output,
            "success": bool(output.get("success", False)) if isinstance(output, dict) else False,
            "tool_call_id": str(getattr(tc, "id", "") or ""),
        }
    )
    _LAST_TOOL_TRACE.records = records
    from app.infrastructure.chat_stream_lifetime import publish_stream_tool_record

    publish_stream_tool_record(copy.deepcopy(records[-1]))


def reset_last_tool_result() -> None:
    _LAST_TOOL_RESULT.set(None)


def _should_replace_tool_result(
    previous: dict[str, Any] | None,
    new_payload: dict[str, Any] | None,
) -> bool:
    if not previous:
        return bool(new_payload)
    if not new_payload:
        return False
    prev_success = previous.get("success") is True
    new_success = new_payload.get("success") is True
    if new_success and not prev_success:
        return True
    if prev_success and not new_success:
        return False
    if new_success and not previous.get("download_url") and new_payload.get("download_url"):
        return True
    return False


def _record_tool_result(tool_key: str, payload: dict[str, Any] | None) -> None:
    if not payload or payload.get("requires_token"):
        return
    record = {
        "tool_key": tool_key,
        "success": payload.get("success"),
        "payload": payload,
    }
    if payload.get("download_url"):
        record["download_url"] = payload.get("download_url")
    previous = _LAST_TOOL_RESULT.get()
    if _should_replace_tool_result(previous, record):
        _LAST_TOOL_RESULT.set(record)


def _tool_key(name: str, args: str) -> str:
    return f"{name}::{args}"


def _parse_generate_office_format(raw_arguments: str) -> str:
    """generate_office_document 的 output_format：docx / xlsx；解析失败返回空串。"""
    try:
        d = json.loads(raw_arguments or "{}")
        if isinstance(d, dict):
            fmt = str(d.get("output_format") or "").strip().lower()
            if fmt in ("docx", "xlsx"):
                return fmt
    except json.JSONDecodeError:
        pass
    return ""


def _tool_stream_call_label(tool_name: str, raw_arguments: str) -> str:
    if tool_name == "generate_office_document":
        fmt = _parse_generate_office_format(raw_arguments)
        if fmt == "docx":
            return "生成 Word 文档（.docx）"
        if fmt == "xlsx":
            return "生成 Excel 工作簿（.xlsx）"
    return _PLANNER_TOOL_STREAM_LABELS.get(tool_name, tool_name)


def _slow_tool_wait_message(tool_name: str, raw_arguments: str) -> str | None:
    """工具执行期间无 token 输出时的等待说明（按工具类型区分，避免合同场景误写「处理 Excel」）。"""
    if tool_name == "import_excel_to_database":
        return "\n（正在将 Excel 导入数据库，通常需数十秒至数分钟，请稍候勿关闭页面。）\n"
    if tool_name == "generate_office_document":
        fmt = _parse_generate_office_format(raw_arguments)
        if fmt == "docx":
            return "\n（正在生成 Word 文档（.docx），通常需数十秒至数分钟，请稍候勿关闭页面。）\n"
        if fmt == "xlsx":
            return (
                "\n（正在生成 Excel 工作簿（.xlsx），通常需数十秒至数分钟，请稍候勿关闭页面。）\n"
            )
        return (
            "\n（正在生成可下载文件（Word 或 Excel），通常需数十秒至数分钟，请稍候勿关闭页面。）\n"
        )
    return None


def _post_tool_round_hint(
    tcs: Sequence[object], tool_payloads: list[dict[str, Any]] | None = None
) -> str:
    """同一轮工具执行完毕后的单行提示；优先依据工具返回 JSON，避免失败仍显示「Word 已就绪」。"""
    payloads = tool_payloads or []
    docx_ok = False
    xlsx_ok = False
    import_ok = False
    fail_msgs: list[str] = []

    for i, t in enumerate(tcs):
        name = str(getattr(getattr(t, "function", None), "name", "") or "")
        raw = str(getattr(getattr(t, "function", None), "arguments", "") or "")
        pl: dict[str, Any] = payloads[i] if i < len(payloads) else {}

        if name == "generate_office_document":
            fmt = _parse_generate_office_format(raw)
            url = str(pl.get("download_url") or "").strip()
            if pl.get("success") is True and url:
                if fmt == "xlsx":
                    xlsx_ok = True
                else:
                    docx_ok = True
            else:
                err = str(pl.get("message") or pl.get("error") or "").strip()
                if pl.get("error") == "duplicate_tool_call":
                    err = err or "重复调用（相同参数已执行过）"
                if not err:
                    err = "文档生成未返回下载链接"
                if len(err) > 100:
                    err = err[:100] + "…"
                fail_msgs.append(err)

        elif name == "import_excel_to_database":
            if pl.get("requires_token"):
                continue
            if pl.get("success") is True:
                import_ok = True

    if fail_msgs and not (docx_ok or xlsx_ok):
        return f"\n[工具未成功：{fail_msgs[0]}，正在生成下一条回复…]\n"

    if docx_ok and not xlsx_ok and not import_ok:
        return "\n[工具已返回（Word 文档可下载），正在生成下一条回复…]\n"
    if xlsx_ok and not docx_ok and not import_ok:
        return "\n[工具已返回（Excel 文件可下载），正在生成下一条回复…]\n"
    if docx_ok and xlsx_ok:
        return "\n[工具已返回（Word 与 Excel 均可下载），正在生成下一条回复…]\n"
    if import_ok and not docx_ok and not xlsx_ok:
        return "\n[工具已返回（Excel 导入结果），正在生成下一条回复…]\n"
    return "\n[工具已返回结果，正在生成下一条回复…]\n"


def _planner_tools_max_workers() -> int:
    raw = (os.environ.get("FHD_PLANNER_TOOLS_MAX_PARALLEL") or "8").strip()
    try:
        n = int(raw)
    except ValueError:
        n = 8
    return max(1, min(n, 32))


def append_tool_messages(
    messages: list[dict[str, Any]],
    tool_calls: list[Any],
    *,
    workspace_root: str | None,
    runtime_context: dict[str, Any] | None = None,
    execute_tool=None,
    db_write_token: str | None = None,
) -> dict[str, Any] | None:
    """执行工具并记录消息；独立调用并行，令牌敏感调用串行且遇授权请求立即返回。"""
    if not tool_calls:
        return None

    if execute_tool is None:
        execute_tool = _resolve_chat_execute_tool()

    parsed: list[tuple[Any, str, str, str]] = []
    for tc in tool_calls:
        fn = getattr(tc, "function", None)
        name = str(getattr(fn, "name", "") or "").strip()
        raw_args = str(getattr(fn, "arguments", "") or "")
        try:
            args_dict = json.loads(raw_args) if raw_args.strip() else {}
            if not isinstance(args_dict, dict):
                args_dict = {}
        except json.JSONDecodeError:
            args_dict = {}
        if name in ("excel_analysis", "excel_schema_understand"):
            args_dict = enrich_excel_tool_arguments(name, args_dict, runtime_context)
        raw_eff = json.dumps(args_dict, ensure_ascii=False)
        key = _tool_key(name, raw_eff)
        parsed.append((tc, name, raw_eff, key))

    any_token_sensitive = any(n in _TOKEN_ORDER_SENSITIVE_TOOLS for _, n, _, _ in parsed)
    max_workers = _planner_tools_max_workers()
    use_parallel = len(parsed) > 1 and max_workers > 1 and not any_token_sensitive

    if not use_parallel:
        for tc, name, raw_eff, key in parsed:
            dedup_state = _tool_dedup_state()
            with _TOOL_DEDUP_LOCK:
                is_dup = key in dedup_state
                if not is_dup:
                    dedup_state.add(key)
            if is_dup:
                payload = {
                    "success": False,
                    "error": "duplicate_tool_call",
                    "hint": "same tool+arguments already executed",
                }
            else:
                payload = json.loads(
                    execute_tool(
                        name,
                        raw_eff,
                        workspace_root,
                        runtime_context=runtime_context,
                        db_write_token=db_write_token,
                    )
                )
            _append_last_tool_record(tc, name, raw_eff, payload)
            if payload.get("requires_token"):
                return payload
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": str(getattr(tc, "id", "") or ""),
                    "content": json.dumps(payload, ensure_ascii=False),
                }
            )
        return None

    payloads: list[dict[str, Any] | None] = [None] * len(parsed)
    to_run: list[tuple[int, str, str]] = []

    dedup_state = _tool_dedup_state()
    with _TOOL_DEDUP_LOCK:
        for i, (_tc, name, raw_eff, key) in enumerate(parsed):
            if key in dedup_state:
                payloads[i] = {
                    "success": False,
                    "error": "duplicate_tool_call",
                    "hint": "same tool+arguments already executed",
                }
            else:
                dedup_state.add(key)
                to_run.append((i, name, raw_eff))

    def _execute_idx(idx: int, name: str, raw_eff: str) -> tuple[int, dict[str, Any]]:
        raw = execute_tool(
            name,
            raw_eff,
            workspace_root,
            runtime_context=runtime_context,
            db_write_token=db_write_token,
        )
        return idx, json.loads(raw)

    def _execute_in_context(
        context: Context, item: tuple[int, str, str]
    ) -> tuple[int, dict[str, Any]]:
        return context.run(_execute_idx, *item)

    first_error = None
    if to_run:
        workers = min(max_workers, len(to_run))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(_execute_in_context, copy_context(), t) for t in to_run]
            for future in futures:
                try:
                    idx, mapped_payload = future.result()
                    payloads[idx] = mapped_payload
                except Exception as exc:  # noqa: BLE001 - collect completed receipts before propagating the first failure
                    if first_error is None:
                        first_error = exc

    if first_error is not None:
        for i, (tc, name, raw_eff, _key) in enumerate(parsed):
            if payloads[i] is not None:
                _append_last_tool_record(tc, name, raw_eff, payloads[i])
        raise first_error

    for i, (tc, _name, _raw_eff, _key) in enumerate(parsed):
        parallel_payload = payloads[i]
        if parallel_payload is None:
            continue
        _append_last_tool_record(tc, _name, _raw_eff, parallel_payload)
        if parallel_payload.get("requires_token"):
            return parallel_payload
        messages.append(
            {
                "role": "tool",
                "tool_call_id": str(getattr(tc, "id", "") or ""),
                "content": json.dumps(parallel_payload, ensure_ascii=False),
            }
        )
    return None


def _call_model_completion(
    messages: list[dict[str, Any]],
    *,
    model: str | None = None,
    client: Any | None = None,
) -> str:
    if client is None:
        require_api_key()
        cli = get_openai_compatible_client()
    else:
        cli = client
    mdl = _resolve_chat_model_for_client(cli, model)
    c = cli.chat.completions.create(model=mdl, messages=messages)
    msg = c.choices[0].message
    return (msg.content or "").strip()


from app.legacy.chat.legacy_chat_runtime import chat as chat
from app.legacy.chat.legacy_chat_runtime import chat_stream_sse_events as chat_stream_sse_events
from app.legacy.chat.legacy_chat_runtime import chat_stream_text as chat_stream_text

__all__ = [
    "reset_planner_tool_dedup_state",
    "clear_last_tool_result",
    "get_last_tool_result",
    "get_last_tool_records",
    "append_tool_messages",
    "chat",
    "chat_stream_text",
    "chat_stream_sse_events",
]
